def simple_func():
    return "I'm simple_func"

print("Test string")
G = 10

if __name__ == "__main__":
    print("Эта строка игнорируется при импорте из данного модуля")
    # Также игнорируется и весь код ниже
    a = 4
    b = 5
    # ...
