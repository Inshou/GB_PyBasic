# ====================
#   Сырые строки r''
# ====================

print("Hello \t world")
print(r"Hello \t world")
#
# # \t - табуляция
# # \n - перенос троки
# # \r - возврат каретки
#
print("Hello \r world")
